Sitema Operacional: Windows 10

IDE: Code::Blocks 20.03

Arquivos do Código-Fonte: dll.c , dll.h e main.c

Executavel: ...\DLLista_CRUD\bin\Debug\DLLista_CRUD.exe
